//
//  BusinessDetailContactCell.swift
//  IndiaSulekha6.3.2
//
//  Created by John Jeswin C on 12/01/16.
//  Copyright © 2016 karthikps. All rights reserved.
//

import UIKit

class BusinessDetailContactCell: UITableViewCell {
    
    @IBOutlet var contentLbl : UILabel!
    @IBOutlet var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
         updateFonts()
    }

    func updateFonts()
    {
        titleLabel.font = UIFont.preferredFontForTextStyle(UIFontTextStyleSubheadline)
        contentLbl.font = UIFont.preferredFontForTextStyle(UIFontTextStyleBody)
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
