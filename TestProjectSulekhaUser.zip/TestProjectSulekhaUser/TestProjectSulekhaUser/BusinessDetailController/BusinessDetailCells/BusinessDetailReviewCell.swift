//
//  BusinessDetailReviewCellTableViewCell.swift
//  IndiaSulekha6.3.2
//
//  Created by John Jeswin C on 19/01/16.
//  Copyright © 2016 karthikps. All rights reserved.
//

import UIKit

class BusinessDetailReviewCell: UITableViewCell {

    @IBOutlet var titleLbl : UILabel!
    @IBOutlet var nameLbl : UILabel!
    @IBOutlet var reviewLabel : UILabel!
    @IBOutlet var dateLbl : UILabel!
    @IBOutlet var ratingView : UIImageView!
    @IBOutlet var reviewBtn : UIButton!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        updateFonts()
    }

    
    func updateFonts()
    {
        titleLbl.font = UIFont.preferredFontForTextStyle(UIFontTextStyleSubheadline)
        nameLbl.font = UIFont.preferredFontForTextStyle(UIFontTextStyleHeadline)
        dateLbl.font = UIFont.preferredFontForTextStyle(UIFontTextStyleCaption1)
        reviewLabel.font = UIFont.preferredFontForTextStyle(UIFontTextStyleBody)
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
