//
//  BusinessDetailUrlCell.swift
//  TestProjectSulekhaUser
//
//  Created by Jeswin on 03/03/16.
//  Copyright © 2016 Jeswin. All rights reserved.
//

import UIKit

class BusinessDetailUrlCell: UITableViewCell {

    
    @IBOutlet var title1 : UILabel!
    @IBOutlet var url1 : UILabel!
    @IBOutlet var title2 : UILabel!
    @IBOutlet var url2 : UILabel!
    @IBOutlet var title3 : UILabel!
    @IBOutlet var url3 : UILabel!
    @IBOutlet var title4 : UILabel!
    @IBOutlet var url4 : UILabel!
    @IBOutlet var title5 : UILabel!
    @IBOutlet var url5 : UILabel!
    @IBOutlet var title6 : UILabel!
    @IBOutlet var url6 : UILabel!
    
    @IBOutlet weak var title1top: NSLayoutConstraint!
    
    @IBOutlet weak var url1top: NSLayoutConstraint!
    
    @IBOutlet weak var title2top: NSLayoutConstraint!
    
    @IBOutlet weak var url2top: NSLayoutConstraint!
    
    @IBOutlet weak var title3top: NSLayoutConstraint!
    
    @IBOutlet weak var url3top: NSLayoutConstraint!
    
    @IBOutlet weak var title4top: NSLayoutConstraint!
    
    @IBOutlet weak var url4top: NSLayoutConstraint!
    
    @IBOutlet weak var title5top: NSLayoutConstraint!
    
    @IBOutlet weak var url5top: NSLayoutConstraint!
    
    @IBOutlet weak var title6top: NSLayoutConstraint!
    
    @IBOutlet weak var url6top: NSLayoutConstraint!

    

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
