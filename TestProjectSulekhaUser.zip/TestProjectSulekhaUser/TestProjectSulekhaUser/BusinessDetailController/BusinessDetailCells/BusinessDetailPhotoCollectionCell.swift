//
//  BusinessDetailPhotoCollectionCell.swift
//  IndiaSulekha6.3.2
//
//  Created by John Jeswin C on 13/01/16.
//  Copyright © 2016 karthikps. All rights reserved.
//

import UIKit

class BusinessDetailPhotoCollectionCell: UICollectionViewCell {
    
    @IBOutlet var photoImageView : UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
