//
//  BusinessDetailPhotoCell.swift
//  IndiaSulekha6.3.2
//
//  Created by John Jeswin C on 13/01/16.
//  Copyright © 2016 karthikps. All rights reserved.
//

import UIKit

class BusinessDetailPhotoCell: UITableViewCell{//, UICollectionViewDataSource, UICollectionViewDelegate {
    
    @IBOutlet var photoCollectionView : UICollectionView!
    @IBOutlet var titleLabel : UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        photoCollectionView.registerNib(UINib(nibName: "BusinessDetailPhotoCollectionCell", bundle: NSBundle.mainBundle()), forCellWithReuseIdentifier: "BusinessDetailPhotoCollectionCell")
        updateFonts()
    }
    
    func updateFonts()
    {
        titleLabel.font = UIFont.preferredFontForTextStyle(UIFontTextStyleSubheadline)
    }
    
    //MARK: - CollectionView Delegate
    
//    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
//        return 1
//    }
//    
//    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//        return 6
//    }
//    
//    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
//        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("BusinessDetailPhotoCollectionCell", forIndexPath: indexPath) as! BusinessDetailPhotoCollectionCell
//        
//        cell.photoImageView.image = UIImage(named: "bmwm2.jpg")
//        return cell
//    }
//    
//    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
//        
//    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
