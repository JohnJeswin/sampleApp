//
//  BusinessReviewListCell.swift
//  TestProjectSulekhaUser
//
//  Created by John Jeswin C on 01/03/16.
//  Copyright © 2016 Jeswin. All rights reserved.
//

import UIKit

class BusinessReviewListCell: UITableViewCell {

    @IBOutlet var nameLbl : UILabel!
    @IBOutlet var dateLbl : UILabel!
    @IBOutlet var reviewLabel : UILabel!
    @IBOutlet var ratingView : UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        updateFonts()
    }

    func updateFonts()
    {
        nameLbl.font = UIFont.preferredFontForTextStyle(UIFontTextStyleHeadline)
        dateLbl.font = UIFont.preferredFontForTextStyle(UIFontTextStyleCaption1)
//        reviewLabel.font = UIFont.preferredFontForTextStyle(UIFontTextStyleBody)
    }

    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
