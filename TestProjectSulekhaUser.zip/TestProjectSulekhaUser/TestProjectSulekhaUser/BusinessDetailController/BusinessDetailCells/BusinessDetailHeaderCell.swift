//
//  BusinessDetailHeaderCell.swift
//  IndiaSulekha6.3.2
//
//  Created by John Jeswin C on 12/01/16.
//  Copyright © 2016 karthikps. All rights reserved.
//

import UIKit

class BusinessDetailHeaderCell: UITableViewCell {
    
    @IBOutlet var roundProgressBarView : UIView!
    @IBOutlet var ratingView : UIImageView!
    @IBOutlet var noOfReviews : UILabel!
    @IBOutlet var businessName : UILabel!
    @IBOutlet var areaLbl : UILabel!
    @IBOutlet var scoreLbl : UILabel!
    var score : CGFloat = 0.0
    var timer : NSTimer!
    var circularBarView = CircularProgressBarView()


    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        circularBarView = CircularProgressBarView(frame: roundProgressBarView.bounds)
        roundProgressBarView.addSubview(circularBarView)
        circularBarView.percent = 100
         timer = NSTimer.scheduledTimerWithTimeInterval(0.1, target: self, selector: "decrementSpin", userInfo: nil, repeats: true)
        ratingView.contentMode = UIViewContentMode.ScaleAspectFit
    }

    func decrementSpin(){
        if circularBarView.percent > Int(score)*10 {
            circularBarView.percent = circularBarView.percent - 1;
            circularBarView.setNeedsDisplay()
        }
        else {
            timer.invalidate()
            timer = nil;
        }
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
        
        
    }
    
}
