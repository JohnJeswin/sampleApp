//
//  BusinessDetailExpandCell.swift
//  IndiaSulekha6.3.2
//
//  Created by John Jeswin C on 03/02/16.
//  Copyright © 2016 karthikps. All rights reserved.
//

import UIKit

class BusinessDetailExpandCell: UITableViewCell {
    
    @IBOutlet var expandableView : UIView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
