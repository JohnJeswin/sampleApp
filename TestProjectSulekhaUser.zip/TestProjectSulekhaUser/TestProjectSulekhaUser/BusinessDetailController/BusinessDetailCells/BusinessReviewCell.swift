//
//  BusinessReviewCell.swift
//  TestProjectSulekhaUser
//
//  Created by Jeswin on 29/02/16.
//  Copyright © 2016 Jeswin. All rights reserved.
//

import UIKit

class BusinessReviewCell: UITableViewCell {
    
    
    @IBOutlet var titleLbl : UILabel!
    @IBOutlet var nameLbl : UILabel!
    @IBOutlet var reviewLabel : UILabel!
    @IBOutlet var dateLbl : UILabel!
    @IBOutlet var ratingView : UIImageView!
    @IBOutlet var reviewBtn : UIButton!

    

    override func awakeFromNib() {
        super.awakeFromNib()
        updateFonts()
        // Initialization code
    }

    func updateFonts()
    {
        titleLbl.font = UIFont.preferredFontForTextStyle(UIFontTextStyleSubheadline)
        nameLbl.font = UIFont.preferredFontForTextStyle(UIFontTextStyleHeadline)
        dateLbl.font = UIFont.preferredFontForTextStyle(UIFontTextStyleCaption1)
        reviewLabel.font = UIFont.preferredFontForTextStyle(UIFontTextStyleBody)
    }

    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
