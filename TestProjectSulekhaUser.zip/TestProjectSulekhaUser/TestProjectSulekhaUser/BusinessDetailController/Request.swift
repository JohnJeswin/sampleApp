//
//  Request.swift
//  IndiaSulekha6.3.2
//
//  Created by BLT0005-IMAC on 14/09/15.
//  Copyright (c) 2015 karthikps. All rights reserved.
//

import Foundation




public enum RequestType : String
{
    case Login = "mode=signin&"
    case Allneeds = "http://spwebapisql.cloudapp.net/api/UserNeed/GetALL_UserPID_ALL_JSON?"
    case Review = "http://lsapi-dev.sulekha.com/api/"
    case GetOffer = "http://ypdb.sulekha.com/api/v1/booking/config/"
    case GetPaymentInfo = "http://ypdb.sulekha.com/api/v1/booking/"
    case SendVoucher = "http://ypdb.sulekha.com/api/v1/"
    case BannerImage = "http://ypdb.sulekha.com/api/v1/booking/promobanner/get"
    
    //GetBusinessDetails
    case BusinessDetail = "http://yellowpages.sulekha.com/api/mobileapi.aspx?"
    case Shortlist = "http://lsapidev2.cloudapp.net/api/users/FavouriteBusiness?"
    
    //Multidimension
    case NeedDefinition = "http://lsapi-dev.sulekha.com/Api/NeedDefinition/"
    //"http://lsv8.cloudapp.net/Api/NeedDefinition/"
    
    case MDLSearch = "http://175.41.139.188/MergeResponseWithoutNeedYP/mergeResponse-yp?wt=json&mp=yp&"
    case MDLNeedsSearch = "http://yellowpages.sulekha.com/api/mobileneedapi.aspx?"
    //22/12/2015
    case RemoveFav = "http://lsapi-dev.sulekha.com/api/users"
    
    
    case GetCountry = "http://lsapi-dev.sulekha.com/api/needdefinition/countries/"
    case GetCity = "http://175.41.139.188/City/citymerge?wt=json&s="
    case GetLocality = "http://175.41.139.188/solr/YPCityAreaNew/yplocalityformobile/suggest?wt=json"
    case GetBrand = "http://lsv8.cloudapp.net/api/needdefinition/products/"
    
    case GetLocationApi = "http://spwebapisql.cloudapp.net/api/UserNeed/GetLocalityByCity_JSON?"
    
    case GetFavourites = "http://lsapi-dev.sulekha.com/api/users/"
    case baseURL = "http://myaccount.sulekha.com/network/sulekhaauth.aspx?"
}


public class Request : NSObject
{//http://spwebapisql.cloudapp.net/api/UserNeed/GetALL_UserPID_ALL_JSON?
    public var requestType: RequestType?
    var stringURL : NSString? = ""
    var paramData = NSData()
    var baseURL : NSString = "http://myaccount.sulekha.com/network/sulekhaauth.aspx?"
    
    override init()
    {
        super.init();
    }

    
   
    
    
    public func initWithTypeString(requestType : RequestType ,paramString : String)-> Request {
        self.requestType = requestType;
        stringURL = stringURL?.stringByAppendingFormat("%@%@",requestType.rawValue,paramString)
        return self;
    }
    
    
    public func initWithType(requestType : RequestType ,paramDict : NSDictionary)-> Request {
        self.requestType = requestType;
        if (paramDict.count == 0)
        {
            stringURL = stringURL?.stringByAppendingFormat("%@",requestType.rawValue)
        }
        else
        {
            stringURL = stringURL?.stringByAppendingFormat("%@%@",requestType.rawValue,paramDict.toURLString())
        }
        return self;
    }
    
    
    //JOhn
    public func initWithPostType(requestType : RequestType ,paramStr : String)-> Request {
        self.requestType = requestType;
        stringURL = "\(requestType.rawValue)"
        paramData = paramStr.dataUsingEncoding(NSUTF8StringEncoding)!
        return self;
    }
    //JOhn
    public func getPostData()-> NSData
    {
        return paramData
    }

    
    public func getURLRequest()-> NSMutableURLRequest
    {
        return NSMutableURLRequest(URL: NSURL(string: stringURL as! String)!)
    }
    
    
    public func getPostParam()-> NSData
    {
        return stringURL!.dataUsingEncoding(NSUTF8StringEncoding)!
    }
}


extension String {
    
    func urlEncodedString() -> String {
        var urlEncodedString = self
        urlEncodedString = urlEncodedString.stringByAddingPercentEscapesUsingEncoding(NSUTF8StringEncoding)!
        return urlEncodedString
    }
}

extension NSDictionary {
    func toURLString() -> String {
        var urlString = ""
        for (paramNameObject, paramValueObject) in self {
            var paramNameEncoded = (paramNameObject as! String).urlEncodedString()
            var paramValueEncoded = (paramValueObject as! String).urlEncodedString()
            var oneUrlPiece = paramNameEncoded + "=" + paramValueEncoded
            urlString = urlString + (urlString == "" ? "" : "&") + oneUrlPiece
        }
        return urlString
    }
}