//
//  CircularProgressBarView.swift
//  IndiaSulekha6.3.2
//
//  Created by John Jeswin C on 20/01/16.
//  Copyright © 2016 karthikps. All rights reserved.
//

import UIKit

class CircularProgressBarView: UIView {

    var startAngle : CGFloat!
    var endAngle : CGFloat!
    var percent : Int!

    override init(frame: CGRect) {
        super.init(frame: frame)
        
//        self.backgroundColor = UIColor.clearColor()
        self.backgroundColor = UIColor(red: 230, green: 230, blue: 238, alpha: 0)
        startAngle = CGFloat(M_PI * 1.5)
        endAngle = startAngle + CGFloat(M_PI * 2)
       

    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)

    }

    
    override func drawRect(rect: CGRect) {
        
        let mainBezierPath : UIBezierPath = UIBezierPath()
        mainBezierPath.addArcWithCenter(CGPointMake(rect.size.width / 2, rect.size.height / 2), radius: 30, startAngle: startAngle, endAngle: (endAngle - startAngle) * (CGFloat(100.0) / 100.0) + startAngle, clockwise: true)
        mainBezierPath.lineWidth = 10
        UIColor(red: 0, green: 100, blue: 0, alpha: 0.2).setStroke()
        mainBezierPath.stroke()

        
        let secondaryBezierPath : UIBezierPath = UIBezierPath()
        secondaryBezierPath.addArcWithCenter(CGPointMake(rect.size.width / 2, rect.size.height / 2), radius: 30, startAngle: startAngle, endAngle: (endAngle - startAngle) * (CGFloat(percent) / 100.0) + startAngle, clockwise: true)
        secondaryBezierPath.lineWidth = 8
        UIColor(red: 0, green: 10 , blue: 0, alpha: 1).setStroke()
        secondaryBezierPath.stroke()


        var valueLbl: UILabel = UILabel()
        valueLbl.frame = CGRectMake(0 , self.frame.size.height/2 - 20, 70, 20)
        valueLbl.font =  UIFont.preferredFontForTextStyle(UIFontTextStyleHeadline)
        valueLbl.textColor = UIColor.blackColor()
        valueLbl.textAlignment = NSTextAlignment.Center
        valueLbl.text = "4.0"
//        self.addSubview(valueLbl)
        
        let centerTitle = UILabel(frame: CGRectMake(0 , self.frame.size.height/2 + 10, 70, 20))
        centerTitle.textAlignment = NSTextAlignment.Center
        centerTitle.font =  UIFont.preferredFontForTextStyle(UIFontTextStyleHeadline)
        centerTitle.text = "Score"
//        self.addSubview(centerTitle)
        
        
        let context : CGContextRef = UIGraphicsGetCurrentContext()!
        CGContextSetStrokeColorWithColor(context, UIColor.whiteColor().CGColor)
        CGContextSetShadowWithColor(context, CGSizeMake(0, 5), 5.0, UIColor.blackColor().CGColor)
//                CGContextDrawPath(context, kCGPathEOFillStroke)
        
        
    }

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}


class RatingImages : UIImage {
    
func imageForRating(rating:Float) -> UIImage? {
    switch rating {
    case 1:
        return UIImage(named: "1.png")
    case 1.5:
        return UIImage(named: "1.5.png")
    case 2:
        return UIImage(named: "2.png")
    case 2.5:
        return UIImage(named: "2.5.png")
    case 3:
        return UIImage(named: "3.png")
    case 3.5:
        return UIImage(named: "3.5.png")
    case 4:
        return UIImage(named: "4.png")
    case 4.5:
        return UIImage(named: "4.5.png")
    case 5:
        return UIImage(named: "Rating_Orange_Iphone.png")
    default:
        return UIImage(named: "Rating_Grey_IPAD.png")
    }
    
}


}