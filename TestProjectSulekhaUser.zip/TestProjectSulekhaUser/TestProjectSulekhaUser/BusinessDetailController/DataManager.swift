//
//  DataManager.swift
//  IndiaSulekha6.3.2
//
//  Created by BLT0005-IMAC on 14/09/15.
//  Copyright (c) 2015 karthikps. All rights reserved.
//

import Foundation

protocol DataManagerDelegate
{
    func dataManagerconnectionDidFinishDelegate(responseDict: AnyObject , requestType : RequestType)
}

public class DataManager : NSObject , NSURLSessionDelegate, NSURLSessionTaskDelegate, NSURLSessionDataDelegate//,NSURLConnectionDelegate , NSURLConnectionDataDelegate
{
    var responseData = NSMutableData()
//    @IBOutlet weak var progressView: UIProgressView!
    var requestClass : Request!
    var delegate : DataManagerDelegate?
//    var activity = TransparentActivity()
    var isActivity : Bool = false
    override init()
    {
        super.init();
    }
    
    public func executeURLConnectionWithRequest(requestMethod : Request , showActivity: Bool)
    {
        self.isActivity = showActivity;
        let mainQueue = NSOperationQueue.mainQueue();
        mainQueue.addOperationWithBlock({ () -> Void in
            self.removeActivity()
            self.addActivity()
        })
        //NSMutableURLRequest(URL: NSURL(string:"http://ypdb.sulekha.com/api/v1/business/3859380/photo")!)//
        self.requestClass = requestMethod
        let request = requestClass.getURLRequest()  //if query string Method
        let data : NSData =  NSData()
//             var data: NSData = requestClass.getPostParam() if Post method attached body
            request.HTTPMethod = "GET"
       
      //  var queue = NSOperationQueue();
       // queue.addOperationWithBlock { () -> Void in
            self.executeURLRequest(request, data: data)
           // var mainQueue = NSOperationQueue.mainQueue();
           // mainQueue.addOperationWithBlock({ () -> Void in
           // })
        //}
    }
    
    
    
    public func executeURLConnectionWithPutRequest(requestMethod : Request , showActivity: Bool)
    {
        self.isActivity = showActivity;
        let mainQueue = NSOperationQueue.mainQueue();
        mainQueue.addOperationWithBlock({ () -> Void in
            self.removeActivity()
            self.addActivity()
        })
        self.requestClass = requestMethod
        let request = requestClass.getURLRequest()  //if query string Method
        let data : NSData =  NSData()
        request.HTTPMethod = "PUT"
        self.executeURLRequest(request, data: data)
    }
    
    public func executeURLConnectionWithPostRequest(requestMethod : Request , showActivity: Bool)
    {
        self.isActivity = showActivity;
        let mainQueue = NSOperationQueue.mainQueue();
        mainQueue.addOperationWithBlock({ () -> Void in
            self.removeActivity()
            self.addActivity()
        })
        self.requestClass = requestMethod
        let request = requestClass.getURLRequest()  //if query string Method
        let data : NSData =  requestClass.getPostData()
        request.HTTPMethod = "POST"
        request.HTTPBody = requestClass.getPostData()
        self.executeURLRequest(request, data: data)
    }

    
    
    //Sangeetha
    public func executeURLConnectionWithDeleteRequest(requestMethod : Request , showActivity: Bool)
    {
        self.isActivity = showActivity;
        let mainQueue = NSOperationQueue.mainQueue();
        mainQueue.addOperationWithBlock({ () -> Void in
            self.removeActivity()
            self.addActivity()
        })
        self.requestClass = requestMethod
        let request = requestClass.getURLRequest()  //if query string Method
        let data : NSData =  NSData()
        request.HTTPMethod = "DELETE"
        self.executeURLRequest(request, data: data)
    }
    
    
   /*  func executeURLRequest(request: NSURLRequest, data: NSData) {
        
        
        let session = NSURLSession.sharedSession()
        
        let task = session.dataTaskWithRequest(request, completionHandler: {data, response, error -> Void in
            var err: NSError?
            var jsonObject: AnyObject? = NSJSONSerialization.JSONObjectWithData(data, options: .MutableLeaves, error: &err)
            if (jsonObject != nil)
            {
                self.delegate?.dataManagerconnectionDidFinishDelegate(jsonObject!, requestType: self.requestClass.requestType!)
            }
            println("RESPONSE DICT : \(jsonObject)")        })
        task.resume()
    }*/
    
    
    func executeURLRequest(request: NSURLRequest, data: NSData) {
        let configuration = NSURLSessionConfiguration.defaultSessionConfiguration()
        let session = NSURLSession(configuration: configuration, delegate: self, delegateQueue: NSOperationQueue.mainQueue())
        let task = session.uploadTaskWithRequest(request, fromData: data)
        task.resume()
    }
    
    public func URLSession(session: NSURLSession, task: NSURLSessionTask, didCompleteWithError error: NSError?) {
        
        if error != nil {
            print("session \(session) occurred error \(error?.localizedDescription)")
        }
        else {
            if self.responseData.length > 0
            {
                let jsonObject: AnyObject? = try! NSJSONSerialization.JSONObjectWithData(self.responseData, options: [.MutableLeaves])
                if (jsonObject != nil)
                {
                    self.delegate?.dataManagerconnectionDidFinishDelegate(jsonObject!, requestType: self.requestClass.requestType!)
                }
                print("RESPONSE DICT : \(jsonObject)")
            }
            else
            {
                let jsonObject: AnyObject! = []
                
                self.delegate?.dataManagerconnectionDidFinishDelegate(jsonObject, requestType: self.requestClass.requestType!)
            }
        }
        self.removeActivity()
    }
    
    public func URLSession(session: NSURLSession, dataTask: NSURLSessionDataTask, didReceiveResponse response: NSURLResponse, completionHandler: (NSURLSessionResponseDisposition) -> Void) {
        print("session \(session), received response \(response)")
        completionHandler(NSURLSessionResponseDisposition.Allow)
    }
    
    public func URLSession(session: NSURLSession, dataTask: NSURLSessionDataTask, didReceiveData data: NSData) {
        responseData.appendData(data)
    }
    
    private func addActivity()
    {
        if self.isActivity == true
        {
//             MBProgressHUD.showHUDAddedTo(UIApplication.sharedApplication().keyWindow, animated: true)
        }
        
       
       /* if((self.activity.superview) == nil && self.isActivity == true)
        {
            activity = TransparentActivity(frame: CGRectMake(0, 0, UIScreen.mainScreen().bounds.size.width,UIScreen.mainScreen().bounds.size.height))
            UIApplication.sharedApplication().keyWindow?.addSubview(activity);
        }*/
    }
    
    
    private func removeActivity()
    {
//        MBProgressHUD.hideHUDForView(UIApplication.sharedApplication().keyWindow, animated: true)

       // self.activity.removeFromSuperview()
    }
    
    
    
    /* public func URLSession(session: NSURLSession, task: NSURLSessionTask, didSendBodyData bytesSent: Int64, totalBytesSent: Int64, totalBytesExpectedToSend: Int64) {
    var uploadProgress: Float = Float(totalBytesSent) / Float(totalBytesExpectedToSend)
    println("session \(session) uploaded \(uploadProgress * 100)%.")
    // progressView.progress = uploadProgress
    }*/
    
    
    
    // Using NSURLConnection Delegate
    /*
    
    func executeURLRequest(request: NSURLRequest, data: NSData) {
    var connection : NSURLConnection = NSURLConnection(request: request, delegate: self, startImmediately:true)!;
    connection.start()
    }
    
    public func connection(connection: NSURLConnection, didReceiveResponse response: NSURLResponse) {
    
    }
    
    public func connection(connection: NSURLConnection, didReceiveData data: NSData) {
    self.responseData.appendData(data);
    }
    
    public func connectionDidFinishLoading(connection: NSURLConnection) {
    var err: NSError?
    var jsonObject: AnyObject? = NSJSONSerialization.JSONObjectWithData(self.responseData, options: .MutableLeaves, error: &err)
    println("RESPONSE DICT : \(jsonObject)")
    }
    
    public func connection(connection: NSURLConnection, didFailWithError error: NSError) {
    println("ERROR : \(error.localizedDescription)")
    
    }*/
    
    
}
