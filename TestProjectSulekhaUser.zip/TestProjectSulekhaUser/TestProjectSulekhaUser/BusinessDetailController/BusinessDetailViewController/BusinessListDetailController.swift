//
//  BusinessListDetailController.swift
//  IndiaSulekha6.3.2
//
//  Created by John Jeswin C on 25/02/16.
//  Copyright © 2016 karthikps. All rights reserved.
//

import UIKit

class BusinessListDetailController: UIViewController,UITableViewDelegate, UITableViewDataSource, UICollectionViewDataSource, UICollectionViewDelegate, DataManagerDelegate, UIScrollViewDelegate {
    
    
    @IBOutlet var callBtn :UIButton!
    var rowsInSection : Int = 1
    
    var servicesAry = [String]()
    var imageAry = [UIImage]()
    var businessDetailDic : [String : AnyObject]!
    var reviewArray = [AnyObject]()
    @IBOutlet var businessDetailTable : UITableView!
    var ratingImage = RatingImages()
    var expandCellArray = [BusinessExpandableCell]()
    var expandArray = [Array<BusinessExpandableCell>]()
    var expandBtnArray = [UIButton]()
    var btnClickIndex :Int!
    var businessDetailModel : BusinessDetailModel!
    var detailTableView = BusinessDetailTableView()
    var businessServiceModel = [BusinessDetailServiceModel]()
    var businessPhotoModel = [BusinessDetailPhotoModel]()
    var businessReviewModel = [BusinessDetailReviewModel]()
    var businessListModel : BusinessListModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        print(businessListModel.ContentId)
        RegisterTableAndCollectionViewCells()
                getPhotos()
        getDetailData()
                getServiceDetails()
                getReviews()
        
        //        let businessDeatilTable = BusinessDetailTableView()
        
        let newStr : String = detailTableView.newMethod("ValueSent")
        print(newStr)
    }
    
    
    func RegisterTableAndCollectionViewCells(){
        expandCellArray.removeAll()
        expandArray.removeAll()
        expandBtnArray.removeAll()
        let expandCell = BusinessExpandableCell()
        expandCellArray.append(expandCell)
        expandCellArray.append(expandCell)
        expandArray.append(expandCellArray)
        expandArray.append(expandCellArray)
        expandArray.append(expandCellArray)
        print(expandArray.count)
        
        
        // Expandable Detail Cell
        
        businessDetailTable.registerNib(UINib(nibName: "BusinessExpandMainCell", bundle: NSBundle.mainBundle()), forCellReuseIdentifier: "BusinessExpandMainCell") //BusinessExpandMainCell
        
        businessDetailTable.registerNib(UINib(nibName: "BusinessExpandableCell", bundle: NSBundle.mainBundle()), forCellReuseIdentifier: "BusinessExpandableCell")
        
        
        // Normal Detail Cell
        businessDetailTable.registerNib(UINib(nibName: "BusinessDetailHeaderCell", bundle: NSBundle.mainBundle()), forCellReuseIdentifier: "BusinessDetailHeaderCell")
        businessDetailTable.registerNib(UINib(nibName: "BusinessDetailContactCell", bundle: NSBundle.mainBundle()), forCellReuseIdentifier: "BusinessDetailContactCell")
        businessDetailTable.registerNib(UINib(nibName: "BusinessDetailPhotoCell", bundle: NSBundle.mainBundle()), forCellReuseIdentifier: "BusinessDetailPhotoCell")
        businessDetailTable.registerNib(UINib(nibName: "BusinessDetailReviewCell", bundle: NSBundle.mainBundle()), forCellReuseIdentifier: "BusinessDetailReviewCell")
        businessDetailTable.registerNib(UINib(nibName: "BusinessEmptyCell", bundle: NSBundle.mainBundle()), forCellReuseIdentifier: "BusinessEmptyCell")
        businessDetailTable.registerNib(UINib(nibName: "BusinessDetailContentCell", bundle: NSBundle.mainBundle()), forCellReuseIdentifier: "BusinessDetailContentCell")
        businessDetailTable.registerNib(UINib(nibName: "BusinessEmptyReviewCell", bundle: NSBundle.mainBundle()), forCellReuseIdentifier: "BusinessEmptyReviewCell")
        
        businessDetailTable.registerNib(UINib(nibName: "BusinessReviewCell", bundle: NSBundle.mainBundle()), forCellReuseIdentifier: "BusinessReviewCell")

//        BusinessDetailUrlCell
        businessDetailTable.registerNib(UINib(nibName: "BusinessDetailUrlCell", bundle: NSBundle.mainBundle()), forCellReuseIdentifier: "BusinessDetailUrlCell")
        businessDetailTable.registerClass(BusinessDetailReviewCell.self, forCellReuseIdentifier:"BusinessDetailReviewCell")
        

        
        businessDetailTable.delegate = self
        businessDetailTable.dataSource = self
        businessDetailTable.rowHeight = UITableViewAutomaticDimension
        businessDetailTable.estimatedRowHeight = 44.0
        
        
    }
    
    //MARK:- Scroll View Delegate
    func scrollViewDidScroll(scrollView: UIScrollView) {
//        let translation : CGPoint = scrollView.panGestureRecognizer.translationInView(scrollView.superview)
//        
//        if translation.y > 0 {
//            print("ScrollDown")
//            UIView.animateWithDuration(0.8, animations: { () -> Void in
//                self.callBtn.frame.origin.y = self.view.frame.size.height +  self.callBtn.frame.size.height
//            })
//        }else if translation.y < 0{
//            print("ScrollUp")
//            UIView.animateWithDuration(0.8, animations: { () -> Void in
//                self.callBtn.frame.origin.y = self.view.frame.size.height -  (self.callBtn.frame.size.height + 50)
//            })
//            
//        }
        
    }
    
    
    override func viewDidAppear(animated: Bool)
    {
        super.viewDidAppear(animated)
        
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "contentSizeCategoryChanged:", name: UIContentSizeCategoryDidChangeNotification, object: nil)
    }
    
    override func viewDidDisappear(animated: Bool)
    {
        super.viewDidDisappear(animated)
        
        NSNotificationCenter.defaultCenter().removeObserver(self, name: UIContentSizeCategoryDidChangeNotification, object: nil)
    }
    
    // This function will be called when the Dynamic Type user setting changes (from the system Settings app)
    func contentSizeCategoryChanged(notification: NSNotification)
    {
        businessDetailTable.reloadData()
    }
    
    
    
    //MARK:- TableView Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 11 + expandArray.count
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if btnClickIndex != nil && section == btnClickIndex {            return rowsInSection
        }
        return 1
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        var cell : UITableViewCell!
        tableView.rowHeight = UITableViewAutomaticDimension
        
        
        if  !(indexPath.section > expandArray.count) {
            
            if indexPath.section > 0 {
                /*
                //            let section3 = tableView.dequeueReusableCellWithIdentifier("BusinessExpandMainCell") as! BusinessExpandMainCell
                let cell3 = tableView.dequeueReusableCellWithIdentifier("BusinessExpandableCell") as! BusinessExpandableCell
                
                let totalrows = tableView.numberOfRowsInSection(indexPath.section)
                
                if indexPath.row == 0 {
                print(indexPath.section)
                let section3 = tableView.dequeueReusableCellWithIdentifier("BusinessExpandMainCell") as! BusinessExpandMainCell
                section3.expandBtn.addTarget(self, action: "expandCellBtnClicked:", forControlEvents: UIControlEvents.TouchUpInside)
                print(expandArray.count)
                if expandBtnArray.count < 3 {//expandArray.count {
                section3.expandBtn.tag = indexPath.section
                print(section3.expandBtn.tag)
                expandBtnArray.append(section3.expandBtn) }
                
                cell = section3
                }else if indexPath.row > 0 {
                if indexPath.row == totalrows-1{
                cell3.addBtn.hidden = false
                }else{
                cell3.addBtn.hidden = true
                }
                tableView.separatorColor = UIColor.clearColor()
                cell3.addBtn.addTarget(self, action: "addExpandRow:", forControlEvents: UIControlEvents.TouchUpInside)
                cell3.deleteBtn.tag = indexPath.row
                cell3.deleteBtn.addTarget(self, action: "deleteExpandRow:", forControlEvents: UIControlEvents.TouchUpInside)
                cell = cell3
                }
                */
//                return  detailTableView.getTotcCell(tableView, indexPath: indexPath)
                cell =  detailTableView.emptyCell(tableView)
            }
            
            
        }
        
        if indexPath.section == 0 { //Business Header
            if businessDetailDic != nil {
                cell = detailTableView.getHeaderCell(tableView, indexPath: indexPath, modelValue: businessDetailModel)
            }else{
                cell = detailTableView.emptyCell(tableView)
            }
        }
        else if indexPath.section == expandArray.count+1 { //Work
            if businessDetailDic != nil {
                cell = detailTableView.getWorkCell(tableView, indexPath: indexPath, modelValue: businessDetailModel)
            }else{
                cell = detailTableView.emptyCell(tableView)
            }
            
        }else if indexPath.section == expandArray.count+2 { //Address //To do - Landmarlk
            if businessDetailDic != nil {
                cell = detailTableView.getAddressCell(tableView, indexPath: indexPath, modelValue: businessDetailModel)
            }else{
                cell = detailTableView.emptyCell(tableView)
            }
            
        }else if indexPath.section == expandArray.count+3{ // Email
            if businessDetailDic != nil {
                cell = detailTableView.getEmailCell(tableView, indexPath: indexPath, modelValue: businessDetailModel)
            }else{
                cell = detailTableView.emptyCell(tableView)
            }
        }
        else if indexPath.section == expandArray.count+4{ //Contact Person
            if businessDetailDic != nil {
                cell = detailTableView.getContactPersonCell(tableView, indexPath: indexPath, modelValue: businessDetailModel)
            }else{
                cell = detailTableView.emptyCell(tableView)
            }
        }
        else if indexPath.section == expandArray.count+5{ //Working hours
            if businessDetailDic != nil {
                cell = detailTableView.getWorkingHourCell(tableView, indexPath: indexPath, modelValue: businessDetailModel)
            }else{
                cell = detailTableView.emptyCell(tableView)
            }
        }
        else if indexPath.section == expandArray.count+6{ // Photo
            let photoCell = tableView.dequeueReusableCellWithIdentifier("BusinessDetailPhotoCell") as! BusinessDetailPhotoCell
            if imageAry.count > 0{
                photoCell.photoCollectionView.delegate = self
                photoCell.photoCollectionView.dataSource = self
                photoCell.photoCollectionView.reloadData()
                cell = photoCell
            }else{
                cell = detailTableView.emptyCell(tableView)
            }
        }
        else if indexPath.section == expandArray.count+7{ //About
            if businessDetailDic != nil {
                cell = detailTableView.getAboutCell(tableView, indexPath: indexPath, modelValue: businessDetailModel)
            }else{
                cell = detailTableView.emptyCell(tableView)
            }
        }
        else if indexPath.section == expandArray.count+8{ //Service offered
            if servicesAry.count > 0{
                cell = detailTableView.getServiceCell(tableView, indexPath: indexPath, modelValue : servicesAry)
            }else{
                cell = detailTableView.emptyCell(tableView)
            }
        }
        else if indexPath.section == expandArray.count+9{ //website /
            if businessDetailDic != nil {
                cell = detailTableView.getWebsiteDetailCell(tableView, indexPath: indexPath, modelValue: businessDetailModel)

            }else{
                cell = detailTableView.emptyCell(tableView)
            }
        }
        else if indexPath.section == expandArray.count+10{
            
            if reviewArray.count > 0 {
                var reviewCell = BusinessReviewCell()
                reviewCell = detailTableView.getReviewCell(tableView, indexPath: indexPath, modelValues: businessReviewModel) as! BusinessReviewCell
                reviewCell.reviewBtn.addTarget(self, action: "reviewButtonAction:", forControlEvents: UIControlEvents.TouchUpInside)
                cell = reviewCell

            }else{
                cell = detailTableView.getEmptyReviewCell(tableView, indexPath: indexPath)
            }
            
        }
        cell.setNeedsUpdateConstraints()
        cell.updateConstraintsIfNeeded()
        
        return cell
    }
    
    func reviewButtonAction(sender : UIButton){
        //BusinessReviewListPush
        guard businessReviewModel.count > 0 else {
            return
        }
        self.performSegueWithIdentifier("BusinessReviewListPush", sender: self)

    }
    
    func expandCellBtnClicked(sender : UIButton){
        btnClickIndex = sender.tag
        print(expandBtnArray.count)
        print(btnClickIndex)
        for selectedBtn in expandBtnArray {
            print(selectedBtn.tag)
            if selectedBtn.tag != btnClickIndex{
                selectedBtn.selected = false
                rowsInSection =  1
            }
            businessDetailTable.reloadData()
        }
        
        if sender.selected == false {               // Default MainAry = 2 & subAry = 2
            print(btnClickIndex)
            rowsInSection =  expandArray[btnClickIndex-1].count
            sender.selected = true
        }else if sender.selected == true {
            rowsInSection = 1
            sender.selected = false
        }
        expandBtnArray.removeAll()
        businessDetailTable.reloadData()
        
        do {
            try rowBtnAction(sender)
        } catch {
            print(error)
        }
        
    }
    
    func rowBtnAction(sender : UIButton) throws{
        
    }
    
    func addExpandRow(sender : UIButton){
        
        let expandCell = BusinessExpandableCell()
        //        expandCellArray.append(expandCell)
        expandArray[btnClickIndex-1].append(expandCell)
        //        rowsInSection = expandCellArray.count + 1
        rowsInSection = expandArray[btnClickIndex-1].count//addAndRemoveArrayValues() + 1 //expandCellArray.count
        businessDetailTable.reloadData()
    }
    
    func deleteExpandRow(sender: UIButton){
        if expandArray[btnClickIndex-1].count > 2{
            //            expandArray[btnClickIndex-1].removeLast()
            expandArray[btnClickIndex-1].removeAtIndex(sender.tag)
        }
        rowsInSection = expandArray[btnClickIndex-1].count //+ 1
        businessDetailTable.reloadData()
    }
    
    func addAndRemoveArrayValues() -> Int{
        //ADD
        for var i = 0; i>expandArray.count; i++ {
            if i == btnClickIndex {
                let expandCell = BusinessExpandableCell()
                expandArray[i].append(expandCell)
                return expandArray[i].count
            }
        }
        return 0
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
//        self.performSegueWithIdentifier("BusinessDetailPush", sender: self)
    }
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "BusinessReviewListPush" {
            let destinationVc = segue.destinationViewController as! BusinessReviewListController
            destinationVc.businessReviewModel = businessReviewModel
            
        }
    }
    
    
    //MARK: - CollectionView Delegate
    
    func numberOfSectionsInCollectionView(collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageAry.count
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        
        return detailTableView.getCollectionCell(collectionView, indexPath: indexPath, images: imageAry)
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        let businessDetailImageView = BusinessImageViewController(nibName :"BusinessImageViewController",bundle:nil)
        businessDetailImageView.selectedIndex = indexPath.row
        businessDetailImageView.slideImages = self.imageAry
        self.presentViewController(businessDetailImageView, animated: true, completion: nil)
        
    }
    
    @IBAction func backAction(sender : UIButton){
        
        self.navigationController?.popViewControllerAnimated(true)
    }
    
    @IBAction func shortlistBusiness(sender : UIButton) {
        // http://lsapidev2.cloudapp.net/api/users/FavouriteBusiness?UserPid=18439405&BusinessId=3570467
        
        let requestString =  String(format:"UserPid=18439405&BusinessId=%d",businessDetailModel.ContentId!)
        assigningPostMethodWithParam(RequestType.Shortlist, formatedString : requestString)

    }
    
    func getPhotos(){
        // _ =  String(format:"http://ypdb.sulekha.com/api/v1/business/%d/photo",Int("1123456")!)http://ypdb.sulekha.com/api/v1/business/3859380/photo
        let requestUrlStr : String = "business/\(businessListModel.ContentId!)/photo"
        assigningGetMethod(RequestType.SendVoucher, formatedString : requestUrlStr)
        
        
    }
    func getDetailData(){
        //        //http://yellowpages.sulekha.com/api/mobileapi.aspx?format=json&cid=3859380
        
        let requestUrlStr : String = "format=json&cid=\(businessListModel.ContentId!)"
        assigningGetMethod(RequestType.BusinessDetail, formatedString : requestUrlStr)
    }
    
    func getServiceDetails(){
        //http://ypdb.sulekha.com/api/v1/business/3859380/service
        let requestUrlStr : String = "business/\(businessListModel.ContentId!)/service"
        assigningGetMethod(RequestType.SendVoucher, formatedString : requestUrlStr)
        
    }
    
    func getReviews(){
        // let postString = "http://myaccount.sulekha.com/network/sulekhaauth.aspx?"
        let Str = "3859380"
        let postData : String = "mode=getBusinessReviews&ypcid=\(businessListModel.ContentId!)&userauth=PPZGySCKmspQ56iALuPpvw=="
        print(postData)
        assigningPostMethod(RequestType.baseURL, formatedString: postData)
        
    }
    
    //MARK: -  Assigning Requests
    private func assigningPostMethod(requestType : RequestType, formatedString : String){
        let request = Request()
        request.initWithPostType(requestType, paramStr: formatedString)
        let dataManager = DataManager()
        dataManager.delegate = self;
        dataManager.executeURLConnectionWithPostRequest(request, showActivity: true)
        
    }
    
    private func assigningPostMethodWithParam(requestType : RequestType, formatedString : String){
        let request = Request()
        request.initWithTypeString(requestType, paramString: formatedString)
        let dataManager = DataManager()
        dataManager.delegate = self;
        dataManager.executeURLConnectionWithPostRequest(request, showActivity: true)
        
    }

    
    private func assigningGetMethod(requestType : RequestType, formatedString : String){
        let request = Request()
        request.initWithTypeString(requestType, paramString: formatedString)
        let dataManager = DataManager()
        dataManager.delegate = self;
        dataManager.executeURLConnectionWithRequest(request, showActivity: true)
        
    }
    
    //MARK:- DataManager Delegate
    func dataManagerconnectionDidFinishDelegate(responseDict: AnyObject, requestType: RequestType) {
        print(responseDict)
        
        if let resultAry : [Dictionary<String, AnyObject>] = responseDict as? [Dictionary<String, AnyObject>] {
            for  result   in resultAry  {
                print(result)
                if let urlstr : String = result["PhotoUrl"] as? String {//photo url
                    print(urlstr)
                    let photoModel = BusinessDetailPhotoModel(modelValues: result)
                    businessPhotoModel.append(photoModel)
                    imageLoading(urlstr)
                    
                }else if let serviceStr : String = result["CategoryTypeName"] as? String {// Service Offered
                    print(serviceStr)
                    let serviceModel = BusinessDetailServiceModel(modelValues: result)
                    businessServiceModel.append(serviceModel)
                    servicesAry.append(serviceStr)
                }
                self.businessDetailTable.reloadData()
            }
            
        }
        else if let resultDic = responseDict.valueForKey("ROW_LISTING")   //["ROW_LISTING"]
        {
            print(resultDic)
        }
            
        else if let resultDic  = responseDict.valueForKey("ROW_DISPLAYBUSINESSPROFILE")  //Business Detail
        {
            businessDetailDic = resultDic.firstObject as! [String: AnyObject]
            self.businessDetailModel = BusinessDetailModel(modelValues: businessDetailDic)
            //            print(resultDic1.firstObject!!.valueForKey("promotionaltext") as! String)
            print(self.businessDetailModel.AreaName)
            print(self.businessDetailModel.CityName)
            print(self.businessDetailDic["score"])
            self.businessDetailTable.reloadData()
        }
        else if let resultDic  = responseDict.valueForKey("DATASET_GET_BUSINESS_REVIEWS")  //Review
        {
            reviewArray = resultDic.valueForKey("ROW_GET_BUSINESS_REVIEWS") as! [AnyObject]
            print(reviewArray.count)
            for  result   in reviewArray  {
                let reviewModel = BusinessDetailReviewModel(modelValues: result)
                businessReviewModel.append(reviewModel)
                
            }
            self.businessDetailTable.reloadData()
        }
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */
    
}


extension BusinessListDetailController{
    func imageLoading(photoUrl : String)  {
        
        let request: NSURLRequest = NSURLRequest(URL:NSURL(string: photoUrl)!)
        let mainQueue = NSOperationQueue.mainQueue()
        NSURLConnection.sendAsynchronousRequest(request, queue: mainQueue, completionHandler: { (response, data, error) -> Void in
            if error == nil {
                // Convert the downloaded data in to a UIImage object
                let image = UIImage(data: data!)
                // Update the cell
                dispatch_async(dispatch_get_main_queue(), {
                    if image  != nil
                    {
                        self.imageAry.append(image! as UIImage)
                        self.businessDetailTable.reloadData()
                    }
                    
                })
            }
        })
        
    }

}
