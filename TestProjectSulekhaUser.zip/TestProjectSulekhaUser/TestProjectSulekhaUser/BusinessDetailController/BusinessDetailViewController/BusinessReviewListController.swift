//
//  BusinessReviewController.swift
//  TestProjectSulekhaUser
//
//  Created by Jeswin on 28/02/16.
//  Copyright © 2016 Jeswin. All rights reserved.
//

import UIKit

class BusinessReviewListController: UIViewController,UITableViewDelegate, UITableViewDataSource, DataManagerDelegate {

    var footerView : UIView!
    var footerIndicator : UIActivityIndicatorView!
    var pageNumber : Int = 1
    var businessReviewModel = [BusinessDetailReviewModel]()
    var ratingImage = RatingImages()
    @IBOutlet var reviewListTable : UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        reviewListTable.delegate = self
        reviewListTable.dataSource = self
        reviewListTable.estimatedRowHeight = 44.0
        reviewListTable.rowHeight = UITableViewAutomaticDimension
        reviewListTable.registerNib(UINib(nibName: "BusinessReviewListCell", bundle: NSBundle.mainBundle()), forCellReuseIdentifier: "BusinessReviewListCell")

        print(businessReviewModel.count)
        
        createFooterView()
        footerView.hidden = true

    }

    
    //MARK:- TableView Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return businessReviewModel.count
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        tableView.rowHeight = UITableViewAutomaticDimension
        let reviewCell = tableView.dequeueReusableCellWithIdentifier("BusinessReviewListCell") as! BusinessReviewListCell
        reviewCell.nameLbl.text = businessReviewModel[indexPath.row].Contributor
        reviewCell.dateLbl.text = businessReviewModel[indexPath.row].PostedDate
        reviewCell.reviewLabel.text = businessReviewModel[indexPath.row].Desc
        reviewCell.ratingView.image = ratingImage.imageForRating(businessReviewModel[indexPath.row].Rating!)
        
        
        if indexPath.row == businessReviewModel.count - 1{
            footerView.hidden = false
            pageNumber = pageNumber + 1
//            getBusinessListData(businessListSortType)
            
        }

        return reviewCell
    }

    //MARK:- Back Action
    @IBAction func backAction(sender : UIButton){
        
        self.navigationController?.popViewControllerAnimated(true)
    }

    //MARK:- Initiate footerView
    func createFooterView(){
        
        self.footerView = UIView(frame: CGRectMake(0, UIScreen.mainScreen().bounds.height - 44, self.reviewListTable.frame.size.width, 44))
        self.footerView.backgroundColor = UIColor.whiteColor()// John
        let indicatorX = UIScreen.mainScreen().bounds.width/2 - 20
        self.footerIndicator  = UIActivityIndicatorView(frame: CGRectMake(indicatorX,0, 40, 40)) as UIActivityIndicatorView
        self.footerIndicator.hidesWhenStopped = true
        self.footerIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.Gray
        self.footerView.addSubview(self.footerIndicator)
        self.footerIndicator.startAnimating()
        
    }

    
    //MARK:- DataManager Delegate
    func dataManagerconnectionDidFinishDelegate(responseDict: AnyObject, requestType: RequestType) {
        //        print(responseDict)
        
        if let resultDic  = responseDict.valueForKey("DATASET_GET_BUSINESS_REVIEWS")  //Review
        {
            let reviewArray = resultDic.valueForKey("ROW_GET_BUSINESS_REVIEWS") as! [AnyObject]
            print(reviewArray.count)
            for  result   in reviewArray  {
                let reviewModel = BusinessDetailReviewModel(modelValues: result)
                businessReviewModel.append(reviewModel)
                
            }
            self.reviewListTable.reloadData()
    }
    
    
}

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
