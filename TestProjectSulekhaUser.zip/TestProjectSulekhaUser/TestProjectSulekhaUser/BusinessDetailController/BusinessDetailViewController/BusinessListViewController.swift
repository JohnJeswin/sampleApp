//
//  BusinessListViewController.swift
//  TestProjectSulekhaUser
//
//  Created by Jeswin on 28/02/16.
//  Copyright © 2016 Jeswin. All rights reserved.
//

import UIKit

enum BusinessListSortType : String {
    
    case SortByDefault
    case SortByRating
    case SortByScore
    
}

class BusinessListViewController: UIViewController,UITableViewDelegate, UITableViewDataSource, DataManagerDelegate, UIScrollViewDelegate {

    var footerView : UIView!
    var footerIndicator : UIActivityIndicatorView!
    @IBOutlet var headerView : UIView!
    @IBOutlet var headerLabel : UILabel!
    @IBOutlet var businessList : UITableView!
    var pageNumber : Int = 1
     var actionButton: ActionButton!
    var businessListSortType : BusinessListSortType = BusinessListSortType.SortByDefault
    
    var businessListModel = [BusinessListModel]()
    
    var sortByDefault : ActionButtonItem! //sortByRating
    var sortByRating : ActionButtonItem!
    var sortByScore : ActionButtonItem!
    var actionButtonArray = [ActionButtonItem]()
    var selectedBusinessIndex : Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        

        createFooterView()
        footerView.hidden = true
        
        businessListSortType = .SortByDefault
        getBusinessListData(businessListSortType)
        initiateSubViews()
    }
    
    
    //MARK:- Initiate Sub Views
    func initiateSubViews(){
        
        // Defining TableView  & Cells
        headerView.layer.cornerRadius = 3.0
        headerView.layer.shadowColor = UIColor.lightGrayColor().CGColor
        headerView.layer.shadowOpacity = 0.7
        
        businessList.delegate = self
        businessList.dataSource = self
        businessList.estimatedRowHeight = 44.0
        businessList.rowHeight = UITableViewAutomaticDimension
        businessList.registerNib(UINib(nibName: "BusinessListCell", bundle: NSBundle.mainBundle()), forCellReuseIdentifier: "BusinessListCell")
        
        let twitterImage = UIImage(named: "twitter_icon.png")
        let plusImage = UIImage(named: "googleplus_icon.png")
        
        sortByDefault = ActionButtonItem(title: "Sort default", image: plusImage)
        sortByDefault.action = { item in self.defaultSortActionClicked() }

        sortByRating = ActionButtonItem(title: "Sort rating", image: twitterImage)
        sortByRating.action = {  item in self.ratingSortActionClicked() }
        
        sortByScore = ActionButtonItem(title: "Sort score", image: plusImage)
        sortByScore.action = { item in self.scoreSortActionClicked() }
        
        actionButtonArray.append(sortByRating)
        actionButtonArray.append(sortByScore)
        
        actionButton = ActionButton(attachedToView: self.view, items: actionButtonArray)
        actionButton.action = { button in button.toggleMenu() }
        actionButton.setTitle("+", forState: .Normal)
        
        actionButton.backgroundColor = UIColor(red: 238.0/255.0, green: 130.0/255.0, blue: 34.0/255.0, alpha:1.0)
        

    }
    
    //MARK:- Sort Button Actions
    func defaultSortActionClicked(){
        
        actionButtonArray.removeAll()
        actionButtonArray.append(sortByRating)
        actionButtonArray.append(sortByScore)
        
        actionButton.items = actionButtonArray
        
        businessListSortType = .SortByDefault
        businessListModel.removeAll()
        businessList.scrollsToTop = true
        getBusinessListData(businessListSortType)

        if actionButton.active {
            actionButton.toggleMenu()
        }


    }
    
    func ratingSortActionClicked(){
        
        actionButtonArray.removeAll()
        actionButtonArray.append(sortByDefault)
        actionButtonArray.append(sortByScore)
        
        actionButton.items = actionButtonArray
        
        businessListSortType = .SortByRating
        businessListModel.removeAll()
        businessList.scrollsToTop = true
        getBusinessListData(businessListSortType)

        if actionButton.active {
            actionButton.toggleMenu()
        }

    }

    func scoreSortActionClicked(){
        
        actionButtonArray.removeAll()
        actionButtonArray.append(sortByDefault)
        actionButtonArray.append(sortByRating)
        actionButton.items = actionButtonArray
        businessListSortType = .SortByScore
        businessListModel.removeAll()
        businessList.scrollsToTop = true
        getBusinessListData(businessListSortType)

        if actionButton.active {
            actionButton.toggleMenu()
        }


    }

    
    //MARK:- Business List Request
    func getBusinessListData(sortType : BusinessListSortType)
    {
        var url:String?
        print(pageNumber)
            url = String(format:"pest-control-services_chennai_%d", pageNumber)
        
        var listSort : String!
        switch sortType {
            
        case .SortByRating:
            listSort = "rating"
            
        case .SortByScore:
            listSort = "scorevalue"
            
        default:
            print("Default")
            listSort = "default"
            
        }
        
        
//        let notificationCenter = NSNotificationCenter.defaultCenter()
//        notificationCenter.addObserver(
//            self,
//            selector: "noBusinessListData:",
//            name: "NoBusinessListDataNotification",
//            object: nil
//        )
        
        
//        let dynamicParam = "pest-control-services_chennai"
        let requestString =  String(format:"format=json&url=%@&sortby=%@",url!,listSort)
        assigningGetMethod(RequestType.BusinessDetail, formatedString : requestString)
        
    }


    //MARK:- Initiate footerView
    func createFooterView(){
        
        self.footerView = UIView(frame: CGRectMake(0, UIScreen.mainScreen().bounds.height - 44, self.businessList.frame.size.width, 44))
        self.footerView.backgroundColor = UIColor.whiteColor()// John
        let indicatorX = UIScreen.mainScreen().bounds.width/2 - 20
        self.footerIndicator  = UIActivityIndicatorView(frame: CGRectMake(indicatorX,0, 40, 40)) as UIActivityIndicatorView
        self.footerIndicator.hidesWhenStopped = true
        self.footerIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.Gray
        self.footerView.addSubview(self.footerIndicator)
        self.footerIndicator.startAnimating()

    }
    

    //MARK:- TableView Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        print(businessListModel.count)
        return businessListModel.count
    }
    
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        tableView.rowHeight = UITableViewAutomaticDimension
        let cell = tableView.dequeueReusableCellWithIdentifier("BusinessListCell") as! BusinessListCell
        
        if let headerLabelText = businessListModel.first?.Subcategory {
            headerLabel.text = "GET QUOTES FOR \(headerLabelText.uppercaseString) "
        }
        
        cell.businessName.text = businessListModel[indexPath.row].BusinessName
        cell.noOfReviews.text = "\(businessListModel[indexPath.row].Reviews!) reviews"
        cell.areaLbl.text = "\(businessListModel[indexPath.row].AreaName!), \(businessListModel[indexPath.row].CityName!)"
        cell.scoreLbl.text = "\(businessListModel[indexPath.row].Score!)"
        cell.score = businessListModel[indexPath.row].Score!
        cell.favBtn.tag = indexPath.row
        cell.favBtn.addTarget(self, action: "businessShortList:", forControlEvents: UIControlEvents.TouchUpInside)
        
        if indexPath.row == businessListModel.count - 1{
            footerView.hidden = false
            pageNumber = pageNumber + 1
            print(businessListSortType)
            getBusinessListData(businessListSortType)
            
        }
        
        return cell
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0.0
    }
    
    func tableView(tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return self.footerView
    }
    
    func tableView(tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
            return 44.0
    }

    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
        selectedBusinessIndex = indexPath.row
            if self.businessListModel[indexPath.row].ContentId != nil{
//              let business_listid = self.businessListModel[indexPath.row].ContentId
//                NSUserDefaults.standardUserDefaults().setObject(business_listid, forKey:"content_id")
                self.performSegueWithIdentifier("BusinessDetailPush", sender: self)
            }
            else
            {
                self.showAlert("Alert", message: "No Content id for Business Detail page", cancelBtn: "OK")
            }
        
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject!) {
        if segue.identifier == "BusinessDetailPush" {
            print("Pushed")
            
            let vc = segue.destinationViewController as! BusinessListDetailController
            vc.businessListModel = businessListModel[selectedBusinessIndex]
        }
    
    }
    
    
    //MARK:- Business Shortlist Request
    func businessShortList(sender : UIButton){
//        let isloggedin:Bool = NSUserDefaults.standardUserDefaults().boolForKey("LoginStatus")
//        if isloggedin == false{
//            let loginAlert = UIAlertView(title: "Alert", message: "Log in to proceed", delegate: self, cancelButtonTitle: "No")
//            
//            loginAlert.addButtonWithTitle("Yes")
//            loginAlert.tag = 67
//            loginAlert.show()
//        }
//        else
//        {
        guard let contentId = businessListModel[sender.tag].ContentId else{
            self.showAlert("Alert", message: "No Content id for shortlist this business", cancelBtn: "Ok")
            return
        }
            // http://lsapidev2.cloudapp.net/api/users/FavouriteBusiness?UserPid=18439405&BusinessId=3570467
            let requestString =  String(format:"UserPid=18439405&BusinessId=%d",contentId)
            assigningPostMethod(RequestType.Shortlist, formatedString : requestString)

//        }

    }
    
    //MARK:- Assigning Request Methods
    private func assigningGetMethod(requestType : RequestType, formatedString : String){
        let request = Request()
        request.initWithTypeString(requestType, paramString: formatedString)
        let dataManager = DataManager()
        dataManager.delegate = self;
        dataManager.executeURLConnectionWithRequest(request, showActivity: true)
        
    }

    private func assigningPostMethod(requestType : RequestType, formatedString : String){
        let request = Request()
        request.initWithTypeString(requestType, paramString: formatedString)// Attaches only parameter
        let dataManager = DataManager()
        dataManager.delegate = self;
        dataManager.executeURLConnectionWithPostRequest(request, showActivity: true)
        
    }

    
    //MARK:- DataManager Delegate
    func dataManagerconnectionDidFinishDelegate(responseDict: AnyObject, requestType: RequestType) {
//        print(responseDict)
        
        if let resultAry : [Dictionary<String, AnyObject>] = responseDict.valueForKey("ROW_LISTING") as? [Dictionary<String, AnyObject>] {
            
            for result in resultAry {
//                print(result)
                let businessList = BusinessListModel(modelValues: result)
                businessListModel.append(businessList)
                print(businessList.StarRating)
                print(businessList.Score)
            }
            footerView.hidden = true
            businessList.reloadData()
        }else if let resultAry : Dictionary<String, AnyObject> = responseDict as? Dictionary<String, AnyObject>{
            if resultAry["BusinessName"] != nil{
                self.showAlert("Success", message: "You've shortlisted this business", cancelBtn: "OK")
            }
        
        }
    }

    
}

extension BusinessListViewController {
    
    func showAlert(title : String, message : String, cancelBtn : String){
        let alert = UIAlertView(title: title, message: message, delegate: self, cancelButtonTitle: cancelBtn)
        alert.show()

    }
}
