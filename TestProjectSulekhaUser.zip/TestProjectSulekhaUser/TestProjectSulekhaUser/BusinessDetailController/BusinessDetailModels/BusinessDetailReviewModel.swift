//
//  BusinessDetailReviewModel.swift
//  TestProjectSulekhaUser
//
//  Created by Jeswin on 26/02/16.
//  Copyright © 2016 Jeswin. All rights reserved.
//

import UIKit

class BusinessDetailReviewModel: NSObject {

    var RowsToFetch : Int?
    var Pageno : Int?
    var RowId : Int?
    var Ypcid : Int?
    var ContentId : Int?
    var Contributor : String?
    var Pid : Int?
    var Rating : Float?
    var CreateDate : String?
    var PostedDate : String?
    var ResPonse : String?
    var Shortdesc : String?
    
    var Totalrecs : Int?
    var DescLength : Int?
    var Desc : String?
    
    
//    "rowstofetch": 10,
//    "pageno": 1,
//    "rowid": 1,
//    "ypcid": 3859380,
//    "contentid": 943558,
//    "contributor": "devaraju",
//    "pid": 883594,
//    "rating": 4,
//    "crdate": "/Date(1456147345377)/",
//    "posteddate": "3 days ago",
//    "response": 0,
//    "htmlurl": "",
//    "shortdesc": "Good service. Humble driver. Vehicles may be little bit comfort.",
//    "totalrecs": 15,
//    "desclength": 69,
//    "desc": "Good service. Humble driver. Vehicles may be little bit comfort."

    
    init(modelValues : AnyObject) {
        self.RowsToFetch =  modelValues["rowstofetch"] as? Int
        self.Pageno =  modelValues["pageno"] as? Int
        self.RowId =  modelValues["rowid"] as? Int
        self.Ypcid =  modelValues["ypcid"] as? Int
        self.ContentId =  modelValues["contentid"] as? Int
        self.Contributor =  modelValues["contributor"] as? String
        self.Pid = modelValues["pid"] as? Int
        self.Rating = modelValues["rating"] as? Float
        self.CreateDate = modelValues["crdate"] as? String
        self.PostedDate = modelValues["posteddate"] as? String
        self.ResPonse = modelValues["response"] as? String
        self.Shortdesc = modelValues["shortdesc"] as? String
        
        self.Totalrecs = modelValues["totalrecs"] as? Int
        self.DescLength = modelValues["desclength"] as? Int
        self.Desc = modelValues["desc"] as? String
        
        
    }
    
    
}


