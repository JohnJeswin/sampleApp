//
//  BusinessDetailModel.swift
//  IndiaSulekha6.3.2
//
//  Created by John Jeswin C on 15/02/16.
//  Copyright © 2016 karthikps. All rights reserved.
//

import UIKit

class BusinessDetailModel: NSObject {
    
    var BusinessName : String?
    var Score : CGFloat?
    var StarRating : Float?
    var ReviewCount : Int?
    var AreaName : String?
    var CityName : String?

    var DispVirtualNo : String?
    var DispMobile : String?
    
    var FormatedAddress : String?
    var Landmark : String?
    var EmailId : String?
    var ContactPerson : String?
    var WorkingHours : String?
    var PromotionalText : String?
    var Website : String?
    var Facebook : String?
    var Twitter : String?
    var Googleplus : String?
    var Youtube : String?
    var LinkedIn : String?
    var ContentId : Int?
    
    
    
    init(modelValues : [String : AnyObject]) {
        
        self.BusinessName = modelValues["businessname"] as? String
        self.ContentId =  modelValues["contentid"] as? Int
        self.Score = modelValues["score"] as? CGFloat
        self.StarRating = modelValues["StarRating"] as? Float
        self.ReviewCount = modelValues["reviewcount"] as? Int
        self.AreaName = modelValues["areaname"] as? String
        self.CityName = modelValues["cityname"] as? String
        self.DispVirtualNo = modelValues["dispvirtualno"] as? String
        self.DispMobile = modelValues["dispmobile"] as? String
        self.FormatedAddress = modelValues["formatedaddress"] as? String
        self.Landmark = modelValues["landmark"] as? String
        self.EmailId = modelValues["emailid"] as? String
        self.ContactPerson = modelValues["contactperson"] as? String
        self.WorkingHours = modelValues["workinghours"] as? String
        self.PromotionalText = modelValues["promotionaltext"] as? String
        
        self.Website = modelValues["website"] as? String
        self.Facebook = modelValues["facebookurl"] as? String
        self.Twitter = modelValues["twitterurl"] as? String
        self.Googleplus = modelValues["googleplusurl"] as? String
        self.Youtube = modelValues["youtubeurl"] as? String
        self.LinkedIn = modelValues["linkedinurl"] as? String

        
    }
    

}

