//
//  BusinessListModel.swift
//  TestProjectSulekhaUser
//
//  Created by John Jeswin C on 02/03/16.
//  Copyright © 2016 Jeswin. All rights reserved.
//

import UIKit

class BusinessListModel: NSObject {
    
    var BusinessName : String?
    var AreaName : String?
    var Reviews : String?
    var StarRating : Float?
    var CityName : String?
    var Score : Float?
    var Subcategory : String?
    var SubcategoryId : Int?
    var PhoneNo : String?
    var DispVirtualNo : String?
    var DispPhoneNo : String?
    var ContentId : Int? // Business ID

    
    init(modelValues : AnyObject) {
        super.init()
        self.BusinessName = modelValues["businessname"] as? String
        self.AreaName = modelValues["areaname"] as? String
        self.Reviews = modelValues["reviews"] as? String
        self.StarRating = modelValues["StarRating"] as? Float
        self.CityName = modelValues["cityname"] as? String
        self.Score = modelValues["score"] as? Float
        self.Subcategory = modelValues["subcategory"] as? String
        self.SubcategoryId = modelValues["subcategoryid"] as? Int
        self.PhoneNo = modelValues["Phone"] as? String
        self.DispVirtualNo = modelValues["dispvirtualno"] as? String
        self.DispPhoneNo = modelValues["dispphoneno"] as? String
        self.ContentId = modelValues["contentid"] as? Int
    }

    
    

}
