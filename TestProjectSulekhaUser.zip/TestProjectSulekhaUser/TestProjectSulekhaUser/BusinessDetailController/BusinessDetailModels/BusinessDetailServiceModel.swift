//
//  BusinessDetailServiceModel.swift
//  IndiaSulekha6.3.2
//
//  Created by John Jeswin C on 24/02/16.
//  Copyright © 2016 karthikps. All rights reserved.
//

import UIKit

class BusinessDetailServiceModel: NSObject {

    var BusinessId : Int?
    var CategoryTypeName : String?
    var SubcategoryId : Int?
    var TypeId : Int?
    var SubCategoryName : String?
    var IsCampaignMapped : Bool?
    var CampaignId : Int?
    var CategoryId : Int?
    var CategoryName : String?
    
    
    init(modelValues : AnyObject) {
        
        self.BusinessId = modelValues["BusinessId"] as? Int
        self.CategoryTypeName = modelValues["CategoryTypeName"] as? String
        self.SubcategoryId = modelValues["SubcategoryId"] as? Int
        self.TypeId = modelValues["TypeId"] as? Int
        self.SubCategoryName = modelValues["SubCategoryName"] as? String
        self.IsCampaignMapped = modelValues["IsCampaignMapped"] as? Bool
        self.CampaignId = modelValues["CampaignId"] as? Int
        self.CategoryId = modelValues["CategoryId"] as? Int
        self.CategoryName = modelValues["CategoryName"] as? String
        
    }

    
    
}
