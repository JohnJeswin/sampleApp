//
//  BusinessDetailPhotoModel.swift
//  IndiaSulekha6.3.2
//
//  Created by John Jeswin C on 22/01/16.
//  Copyright © 2016 karthikps. All rights reserved.
//

import UIKit

class BusinessDetailPhotoModel: NSObject {

   /* "BusinessPhotoId": 257965,
    "BusinessId": 3859380,
    "PhotoUrl": "http://localserviceassets.blob.core.windows.net:80/businessphoto-m/logo-8f18e0b9-e33f-4f5d-979d-55cebef5e25e.png",
    "Caption": "",
    "UploadDate": "2015-12-30T01:35:39.52",
    "IsVerified": true
    */
    
    var BusinessPhotoId : Int?
    var BusinessId : Int?
    var PhotoUrl : String?
    var Caption : String?
    var UploadDate : String?
    var IsVerified : Bool?
    var previewImage : UIImage?
    
    
    
//    init(businessPhotoId : Int, businessId : Int, photoUrl : String, caption : String, uploadDate : String, isVerified : Bool) {
//        
//        self.BusinessPhotoId = businessPhotoId
//        self.BusinessId = businessId
//        self.PhotoUrl = photoUrl
//        self.Caption = caption
//        self.UploadDate = uploadDate
//        self.IsVerified = isVerified
//        
    
    
//    }
    
    
    init(modelValues : AnyObject) {
        super.init()
        self.BusinessPhotoId = modelValues["BusinessPhotoId"] as? Int
        self.BusinessId = modelValues["BusinessId"] as? Int
        self.PhotoUrl = modelValues["PhotoUrl"] as? String
        self.Caption = modelValues["Caption"] as? String
        self.UploadDate = modelValues["UploadDate"] as? String
        self.IsVerified = modelValues["IsVerified"] as? Bool
        
    }
    
    

    
}

