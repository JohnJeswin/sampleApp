//
//  BusinessListCell.swift
//  TestProjectSulekhaUser
//
//  Created by Jeswin on 28/02/16.
//  Copyright © 2016 Jeswin. All rights reserved.
//

import UIKit

class BusinessListCell: UITableViewCell {

    @IBOutlet var roundProgressBarView : UIView!
    @IBOutlet var ratingView : UIImageView!
    @IBOutlet var noOfReviews : UILabel!
    @IBOutlet var businessName : UILabel!
    @IBOutlet var areaLbl : UILabel!
    @IBOutlet var scoreLbl : UILabel!
    @IBOutlet var callBtn : UIButton!
    @IBOutlet var favBtn : UIButton!
    @IBOutlet var chatBtn : UIButton!

    var score : Float = 0.0
    var timer : NSTimer!
    var circularBarView = CircularProgressBarView()

    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        circularBarView = CircularProgressBarView(frame: roundProgressBarView.bounds)
        roundProgressBarView.addSubview(circularBarView)
        circularBarView.percent = 100
        timer = NSTimer.scheduledTimerWithTimeInterval(0.1, target: self, selector: "decrementSpin", userInfo: nil, repeats: true)
        ratingView.contentMode = UIViewContentMode.ScaleAspectFit

        
    }

    func decrementSpin(){
        if circularBarView.percent > Int(score)*10 {
            circularBarView.percent = circularBarView.percent - 1;
            circularBarView.setNeedsDisplay()
        }
        else {
            timer.invalidate()
            timer = nil;
        }
    }

//    override func setSelected(selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//        if(selected) {
////            self.layer.backgroundColor = UIColor.yellowColor().CGColor
//            
////            roundProgressBarView
//            let bounceAnimation = CAKeyframeAnimation(keyPath: "transform.scale")
//            
//            bounceAnimation.values = [1.0 ,0.95,0.9, 1.15, 0.95, 1.02, 1.0]
////            bounceAnimation.values = [1.0,0.9]
//            
//            bounceAnimation.duration = NSTimeInterval(0.5)
//            
//            bounceAnimation.calculationMode = kCAAnimationCubic
//            
//            favBtn.layer.addAnimation(bounceAnimation, forKey: nil)
//            
//
//            
//        }
//    }
//    
//    override func setHighlighted(highlighted: Bool, animated: Bool) {
//        super.setHighlighted(highlighted, animated: animated)
//        let bounceAnimation = CAKeyframeAnimation(keyPath: "transform.scale")
//        
//        bounceAnimation.values = [1.0 ,0.95,0.8, 0.8, 0.75]
//        
//        bounceAnimation.duration = NSTimeInterval(0.5)
//        
//        bounceAnimation.calculationMode = kCAAnimationCubic
//        
//        self.layer.addAnimation(bounceAnimation, forKey: nil)
//
//        if(highlighted) {
//        }
//    }

    
    
//    override func setSelected(selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }
    
}
