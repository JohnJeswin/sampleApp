//
//  BusinessDetailExpandableView.swift
//  IndiaSulekha6.3.2
//
//  Created by John Jeswin C on 03/02/16.
//  Copyright © 2016 karthikps. All rights reserved.
//

import UIKit

class BusinessDetailExpandableView: UIViewController,UITableViewDataSource, UITableViewDelegate {

    @IBOutlet var expandableTableView : UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        expandableTableView.registerNib(UINib(nibName: "BusinessExpandableCell", bundle: nil), forCellReuseIdentifier: "BusinessExpandableCell")
    }
    //MARK:- TableView Delegate
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return 11
    }

    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("BusinessExpandableCell") as! BusinessExpandableCell
        cell.textLabel?.text = "Label\(indexPath.row)"
        return cell
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
