//
//  BusinessDetailTableView.swift
//  IndiaSulekha6.3.2
//
//  Created by John Jeswin C on 23/02/16.
//  Copyright © 2016 karthikps. All rights reserved.
//

import UIKit

struct BusinessDetailConstant {
    //    static
    let EmptyCell = "BusinessEmptyCell"
    let TotcCell = "BusinessExpandMainCell"
    let HeaderCell = "BusinessDetailHeaderCell"
    let ContactCell = "BusinessDetailContactCell"
    let PhotoCell = "BusinessDetailPhotoCell"
    let ReviewCell = "BusinessReviewCell"
    let EmptyReviewCell = "BusinessEmptyReviewCell"
    let WebsiteDetailCell = "BusinessDetailContentCell"
    
    let ImageCollectionCell = "BusinessDetailPhotoCollectionCell"
}


struct BusinessDetailTableView  {
    
    let businessDetailConstant = BusinessDetailConstant()
    var businessDetailPhotoModel = [BusinessDetailPhotoModel]()
    var businessDetailModel : BusinessDetailModel!
    var ratingImage = RatingImages()
    
    
    
    // Sample
    func newMethod(str : String) -> String {
        print("Value Received")
        return "Success"
    }
    
    //MARK:- Collection Details
    func getCollectionCell(collectionView : UICollectionView, indexPath :NSIndexPath, images : [UIImage]) -> UICollectionViewCell{
        let imageCell = collectionView.dequeueReusableCellWithReuseIdentifier(businessDetailConstant.ImageCollectionCell, forIndexPath: indexPath) as! BusinessDetailPhotoCollectionCell
        
        imageCell.photoImageView.image = images[indexPath.row]
        
        return imageCell
    }
    
    
    //MARk:- Table Details
    func emptyCell(tableView : UITableView) -> UITableViewCell{
        let emptyCell = tableView.dequeueReusableCellWithIdentifier(businessDetailConstant.EmptyCell) as! BusinessEmptyCell
        tableView.rowHeight = 0.0
        return emptyCell
    }
    
    func contactCommomCell(tableView : UITableView) -> UITableViewCell{
        let commomCell = tableView.dequeueReusableCellWithIdentifier(businessDetailConstant.ContactCell) as! BusinessDetailContactCell
        return commomCell
    }
    
    func getTotcCell(tableView : UITableView, indexPath :NSIndexPath) -> UITableViewCell{
        let totcCell = tableView.dequeueReusableCellWithIdentifier(businessDetailConstant.TotcCell) as! BusinessExpandMainCell
        
        return totcCell
    }
    
    //Header
    func getHeaderCell(tableView : UITableView, indexPath :NSIndexPath, modelValue : BusinessDetailModel) -> UITableViewCell{
        let headerCell = tableView.dequeueReusableCellWithIdentifier(businessDetailConstant.HeaderCell) as! BusinessDetailHeaderCell
        headerCell.businessName.text = modelValue.BusinessName
        headerCell.noOfReviews.text = "\(modelValue.ReviewCount!) reviews"
        headerCell.areaLbl.text = "\(modelValue.AreaName!), \(modelValue.CityName!)"
        print(modelValue.StarRating)
        headerCell.scoreLbl.text = "\(modelValue.Score!)"
        headerCell.score = modelValue.Score!
        headerCell.ratingView.image = ratingImage.imageForRating(modelValue.StarRating!)
        return headerCell
    }
    
    //Work
    func getWorkCell(tableView : UITableView, indexPath :NSIndexPath, modelValue : BusinessDetailModel) -> UITableViewCell{
        let workCell = contactCommomCell(tableView) as! BusinessDetailContactCell
        workCell.titleLabel.text = "Work"
        
        guard let mobileNo = modelValue.DispVirtualNo else{
            workCell.contentLbl.text = modelValue.DispMobile
            return workCell
        }
        workCell.contentLbl.text = mobileNo
        return workCell
    }
    
    //Address
    func getAddressCell(tableView : UITableView, indexPath :NSIndexPath, modelValue : BusinessDetailModel) -> UITableViewCell{
        let addressCell = contactCommomCell(tableView) as! BusinessDetailContactCell
        addressCell.titleLabel.text = "Address"
        addressCell.contentLbl.text = modelValue.FormatedAddress
        return addressCell
    }
    
    //Email
    func getEmailCell(tableView : UITableView, indexPath :NSIndexPath, modelValue : BusinessDetailModel) -> UITableViewCell{
        let emailCell = contactCommomCell(tableView) as! BusinessDetailContactCell
        emailCell.titleLabel.text = "Email"
        emailCell.contentLbl.text = modelValue.EmailId
        return emailCell
    }
    
    //ContactPerson
    func getContactPersonCell(tableView : UITableView, indexPath :NSIndexPath, modelValue : BusinessDetailModel) -> UITableViewCell{
        let contactPersonCell = contactCommomCell(tableView) as! BusinessDetailContactCell
        contactPersonCell.titleLabel.text = "Contact person"
        contactPersonCell.contentLbl.text = modelValue.ContactPerson
        return contactPersonCell
    }
    
    //Working Hours
    func getWorkingHourCell(tableView : UITableView, indexPath :NSIndexPath, modelValue : BusinessDetailModel) -> UITableViewCell{
        let workingHourCell = contactCommomCell(tableView) as! BusinessDetailContactCell
        workingHourCell.titleLabel.text = "Working hours"
        workingHourCell.contentLbl.text = modelValue.WorkingHours
        return workingHourCell
    }
    
    //About
    func getAboutCell(tableView : UITableView, indexPath :NSIndexPath, modelValue : BusinessDetailModel) -> UITableViewCell{
        let aboutCell = contactCommomCell(tableView) as! BusinessDetailContactCell
        aboutCell.titleLabel.text = "About"
        aboutCell.contentLbl.text = modelValue.PromotionalText
        return aboutCell
    }
    
    //ServiceOffered
    func getServiceCell(tableView : UITableView, indexPath :NSIndexPath, modelValue : [String]) -> UITableViewCell{
        let serviceCell = contactCommomCell(tableView) as! BusinessDetailContactCell
        serviceCell.titleLabel.text = "Services offered"
        serviceCell.contentLbl.text =  modelValue.joinWithSeparator("\n")
        return serviceCell
    }
    
    //Photo
    func getPhotoCell(tableView : UITableView, indexPath :NSIndexPath) -> UITableViewCell{
        let photoCell = tableView.dequeueReusableCellWithIdentifier(businessDetailConstant.PhotoCell) as! BusinessDetailPhotoCell
        return photoCell
    }
    
    
    func collectingWebsiteValues(tableView : UITableView, indexPath :NSIndexPath, modelValue : BusinessDetailModel)  -> [String]{
        
        var websiteAry = [String]()
        
        var count :Int = 0
        
        for var i = 0; i<6; i++ {
            
            if count == 0 {
                if  modelValue.Website == ""{
                    websiteAry.append("Website:")
                    websiteAry.append("website.com")
                }
            }else if count == 1 {
                if modelValue.Facebook == ""{
                    websiteAry.append("Facebook:")
                    websiteAry.append("facebook.com")

                }
            }else if count == 2 {
                if modelValue.Twitter == ""{
                    websiteAry.append("Twitter:")
                    websiteAry.append("Twitter.com")
                }
            }else if count == 3 {
                if modelValue.Googleplus == ""{
                    websiteAry.append("Googleplus:")
                    websiteAry.append("Googleplus.com")
                }
            }else if count == 4 {
                if modelValue.Youtube == ""{
                    websiteAry.append("Youtube:")
                    websiteAry.append("Youtube.com")
                }
            }else if count == 5 {
                if modelValue.LinkedIn == ""{
                    websiteAry.append("Linkedinurl:")
                    websiteAry.append("linked.com")
                }
            }
            count = count+1
        }
        return websiteAry
        
    }
    
    
    
    
    //Website
    func getWebsiteDetailCell(tableView : UITableView, indexPath :NSIndexPath, modelValue : BusinessDetailModel) -> UITableViewCell{
        
        let websiteCell = tableView.dequeueReusableCellWithIdentifier(businessDetailConstant.ContactCell) as! BusinessDetailContactCell
let ary = collectingWebsiteValues(tableView, indexPath: indexPath, modelValue: modelValue)
        
        websiteCell.titleLabel.text = "Website"
        websiteCell.contentLbl.text =  ary.joinWithSeparator("\n")
        
        
        
//        let websiteCell = tableView.dequeueReusableCellWithIdentifier(businessDetailConstant.WebsiteDetailCell) as! BusinessDetailContentCell
//        var count :Int = 0
//        var rowCount :Int = 0
//        var extraHeight : Int = 5
//        
//        for var i = 0; i<6; i++ {
//            
//            if count == 0 {
//                if  modelValue.Website == ""{
//                    websiteCell.title1.text = "Website"
//                    websiteCell.url1.text = "website.com"//modelValue.Website
//                    rowCount = 1+rowCount
//                    extraHeight = 10
//                }
//                else{
//                    websiteCell.url1top.constant = 0
//                }
//            }else if count == 1 {
//                if modelValue.Facebook == ""{
//                    websiteCell.title2.text = "Facebook"
//                    websiteCell.url2.text = "facebook.com"//modelValue.Facebook
//                    rowCount = 1+rowCount
//                    extraHeight = 10*2
//                }else{
//                    websiteCell.title2top.constant = 0
//                    websiteCell.url2top.constant = 0
//                }
//            }else if count == 2 {
//                if modelValue.Twitter != ""{
//                    websiteCell.title3.text = "Twitter"
//                    websiteCell.url3.text = modelValue.Twitter
//                    rowCount = 1+rowCount
//                    extraHeight = 10*3
//                }else{
//                    websiteCell.title3top.constant = 0
//                    websiteCell.url3top.constant = 0
//                    
//                }
//            }else if count == 3 {
//                if modelValue.Googleplus == ""{
//                    websiteCell.title4.text = "Googleplus"
//                    websiteCell.url4.text = "Googleplus.com"//modelValue.Googleplus
//                    rowCount = 1+rowCount
//                    extraHeight = 10*4
//                }else{
//                    websiteCell.title4top.constant = 0
//                    websiteCell.url4top.constant = 0
//                    
//                }
//            }else if count == 4 {
//                if modelValue.Youtube != ""{
//                    websiteCell.title5.text = "Youtube"
//                    websiteCell.url5.text = modelValue.Youtube
//                    rowCount = 1+rowCount
//                    extraHeight = 10*5
//                }else{
//                    websiteCell.title5top.constant = 0
//                    websiteCell.url5top.constant = 0
//                    
//                }
//            }else if count == 5 {
//                if modelValue.LinkedIn == ""{
//                    websiteCell.title6.text = "Linkedinurl"
//                    websiteCell.url6.text = "linked.com"//modelValue.LinkedIn
//                    rowCount = 1+rowCount
//                    extraHeight = 10*6
//                }else{
//                    websiteCell.title6top.constant = 0
//                    websiteCell.url6top.constant = 0
//                }
//            }
//            count = count+1
//        }
//        tableView.rowHeight = CGFloat(rowCount * 51 + extraHeight)
        
        return websiteCell
    }
    
    //Review
    func getReviewCell(tableView : UITableView, indexPath :NSIndexPath, modelValues : [BusinessDetailReviewModel]) -> UITableViewCell{
        
        let reviewCell = tableView.dequeueReusableCellWithIdentifier(businessDetailConstant.ReviewCell) as! BusinessReviewCell
        let firstReview = modelValues.first! as BusinessDetailReviewModel
        print(firstReview.Contributor)
        print(modelValues.first?.Contributor)
        reviewCell.nameLbl.text = firstReview.Contributor
        reviewCell.dateLbl.text = firstReview.PostedDate
        reviewCell.reviewLabel.text = firstReview.Desc
//        let btnTitle = modelValues.count > 1 ? " WRITE REVIEWS" : "VIEW MORE REVIEWS"//"VIEW MORE REVIEWS" : "WRITE REVIEWS"
        let btnTitle = modelValues.count > 1 ? "VIEW MORE REVIEWS" : "WRITE REVIEWS"//"VIEW MORE REVIEWS" : "WRITE REVIEWS"
        reviewCell.reviewBtn.setTitle(btnTitle, forState: .Normal)
        reviewCell.ratingView.image = ratingImage.imageForRating(firstReview.Rating!)
        
        return reviewCell
    }
    
    
    //Write Review
    func getEmptyReviewCell(tableView : UITableView, indexPath :NSIndexPath) -> UITableViewCell{
        let emptyReviewCell = tableView.dequeueReusableCellWithIdentifier(businessDetailConstant.EmptyReviewCell) as! BusinessEmptyReviewCell
        
        return emptyReviewCell
    }
    
    
    
}

