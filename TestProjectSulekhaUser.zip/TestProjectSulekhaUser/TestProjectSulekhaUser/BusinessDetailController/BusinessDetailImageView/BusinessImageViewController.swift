//
//  BusinessImageViewController.swift
//  IndiaSulekha6.3.2
//
//  Created by John Jeswin C on 02/02/16.
//  Copyright © 2016 karthikps. All rights reserved.
//

import UIKit

class BusinessImageViewController: UIViewController, UIPageViewControllerDataSource {

    private var pageViewController: UIPageViewController?
    var slideImages :[UIImage]!
    var selectedIndex : Int!
    @IBOutlet var backView : UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        let itemController = BusinessPageItemController()
//        itemController.itemIndex = 2
        // Do any additional setup after loading the view.
        createPageViewController()
        setupPageControl()

    }

    private func createPageViewController() {
        
        let pageController = BusinessPageViewController(nibName:"BusinessPageViewController", bundle: nil)as UIPageViewController
        
        pageController.dataSource = self
        print(slideImages.count)
        if slideImages.count > 0 {
            let firstController = getItemController(selectedIndex)!
            let startingViewControllers: NSArray = [firstController]
            pageController.setViewControllers(startingViewControllers as? [UIViewController], direction: UIPageViewControllerNavigationDirection.Forward, animated: false, completion: nil)
        }
        
        pageViewController = pageController
        addChildViewController(pageViewController!)
        backView.addSubview(pageViewController!.view)
        pageViewController!.view.frame = backView.bounds
        pageViewController!.didMoveToParentViewController(self)
//        pageViewController!.transitionStyle = UIPageViewControllerTransitionStyle.Scroll
    }
    
    private func setupPageControl() {
        let appearance = UIPageControl.appearance()
        appearance.pageIndicatorTintColor = UIColor.grayColor()
        appearance.currentPageIndicatorTintColor = UIColor.whiteColor()
        appearance.backgroundColor = UIColor.darkGrayColor()
    }
    
    // MARK: - UIPageViewControllerDataSource
    
    func pageViewController(pageViewController: UIPageViewController, viewControllerBeforeViewController viewController: UIViewController) -> UIViewController? {
        
        let itemController = viewController as! BusinessPageItemController
        
//        itemController.itemIndex = 2
        if itemController.itemIndex > 0 {
            return getItemController(itemController.itemIndex-1)
        }
        
        return nil
    }
    
    func pageViewController(pageViewController: UIPageViewController, viewControllerAfterViewController viewController: UIViewController) -> UIViewController? {
        
        let itemController = viewController as! BusinessPageItemController
        
        if itemController.itemIndex+1 < slideImages.count {
            return getItemController(itemController.itemIndex+1)
        }
        
        return nil
    }
    
    private func getItemController(itemIndex: Int) -> BusinessPageItemController? {
        
        if itemIndex < slideImages.count {

            let pageItemController = BusinessPageItemController(nibName:"BusinessPageItemController", bundle: nil)// self.storyboard!.instantiateViewControllerWithIdentifier("ItemController") as! PageItemController
            pageItemController.itemIndex = itemIndex
            pageItemController.imageName = slideImages[itemIndex]
            return pageItemController
        }
        
        return nil
    }
    
    // MARK: - Page Indicator
    
    func presentationCountForPageViewController(pageViewController: UIPageViewController) -> Int {
        return slideImages.count
    }
    
    func presentationIndexForPageViewController(pageViewController: UIPageViewController) -> Int {
        return selectedIndex
    }
    
    @IBAction func backAction(sender: UIButton){
    self.dismissViewControllerAnimated(true, completion: nil)
    }

}
